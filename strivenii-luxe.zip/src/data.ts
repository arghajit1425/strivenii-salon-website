import { Service, Review, GalleryItem } from './types';

export const HERO_IMAGE = "https://lh3.googleusercontent.com/aida-public/AB6AXuCNdNIhljoKAUrbuI2eHg2XLriU9yU5hrTl3iXaqV-Me0wWVD8YKxJvGvvzhGPGCgw28EuyeFFlDr5RtbbvFXKvITY4U_GsehmhKLVg8kDXpiqDypcfZ5_xx8Cc3JbR-ZehTC67zdv7TVqM0jNI-7_E2WNDc1kyRN0V2gnseoeutY4aBXcpjSDZqdUSO8D-Jbd3TD6u4gPbaIVd7uWD5Us-GbVD-2xiv5yK0lX_7ht7TAs8rkJYY3a7btZQVzAY93wOxNDz_ArJsA";
export const ABOUT_IMAGE = "https://lh3.googleusercontent.com/aida-public/AB6AXuCojbvWYrF9fssWrfNmDhaiBkDtnSGAN2iKfua01iHBkM3i7q7OGk-LF6-6_DGOPhhEBsBydoIy0pQQUwRDaD4YNXMXM43_OTvwb9mS1Q2XBIopLg7eseFyD_3I9RpJFbUAfWk3wL8FZM1xkia81_DBjwGkEWPi64j5Y-wUJzBAigKXTcvkW60aF-9LtEH_FNgENyfRYPdI8qlTRvvD87QS93guuXV-qiUkx2wmgXdQ3G_jpQkGzVFvzf-Rc1zwkpSw6EkMG47GHw";
export const CTA_TOOLS_IMAGE = "https://lh3.googleusercontent.com/aida-public/AB6AXuDx_1uttKXJ0-FqWCatOoogRTTq3UHiZh8Xj0lqrcbMxlfQlSXpbSCx7DDuR7bKComm5iozk6-yXuZIi-OWlQ0Q201suyTmM5fTsrD6EIdG3inKi0AqtW_7obWUWmrCt_XwnO2oWjfyXf5U8yLg_0S9OfZ38whY9MQPSVIZVSyq0GJrUoT5Rp60X4hLIBSA2TYRwAkoLhdmxy8eXWVhsrVBGMZsEGZCZArJ6lwL84rR8Oxpz0nxtgj_BB1THkrSgYct6w3XoUbaAA";
export const MAP_IMAGE = "https://lh3.googleusercontent.com/aida-public/AB6AXuDiMM99M5EAXA4HTFZVGSSm15BOKoRmKWg_z8gYoWWjbq7FkkNiu1CjppMvMKPSTzza-6_GpvkjciYgAkm3ydmIxSz3A9_2hqQIeGXZu5NG0z0L5hMZ254zo8ARu1l7GpQZ2OnL5F2XQ8qxoJ6Nbu58Yosl3iV1U2Roi5z31k9U1XGtN9kDhqaHnbtduXXne0lPvFWKkkatTtBBTYm6lydzfk5Mc9iU9MaeghRpXkYjPTVuSu4ZE_6pH3SPBmcLfQxzH_WAcm2fuw";

export const SERVICES: Service[] = [
  {
    id: "hair-styling-custom",
    name: "Editorial Blowout & Precision Style",
    category: "styling",
    categoryLabel: "STYLING & CUTS",
    description: "Personalized custom haircuts, deep hydration treatment, and professional styling designed by our master artists.",
    price: "₹3,500",
    duration: "60 mins",
    iconName: "Scissors"
  },
  {
    id: "spa-ritual",
    name: "Royal Rejuvenation Ritual",
    category: "spa",
    categoryLabel: "REJUVENATION",
    description: "An immersive relaxation experience targeting scalp tension, neck stiffness, and full body restoration with holistic botanical oils.",
    price: "₹6,000",
    duration: "90 mins",
    iconName: "Flower"
  },
  {
    id: "artisanal-color",
    name: "Signature Balayage & Tonal Gloss",
    category: "color",
    categoryLabel: "COLOR ARTISTRY",
    description: "Bespoke hand-painted highlights customized to trace your natural hair movement using organic, ammonia-free elixirs.",
    price: "₹12,500",
    duration: "180 mins",
    iconName: "Palette"
  },
  {
    id: "bridal-makeup",
    name: "Celestial HD Bridal Glamour",
    category: "bridal",
    categoryLabel: "BRIDAL COUTURE",
    description: "Premium high-definition airbrush bridal transformation, customized to enhance your natural glow for standard to multiple ceremonies.",
    price: "₹25,000",
    duration: "150 mins",
    iconName: "Sparkles"
  },
  {
    id: "advanced-facials",
    name: "Micro-Dermal Oxygen Infusion",
    category: "facials",
    categoryLabel: "SKINCARE",
    description: "Deep pore-cleansing aesthetic technique backed by advanced hydration cocktails to instantly lift, tighten, and illuminate.",
    price: "₹8,500",
    duration: "75 mins",
    iconName: "Smile"
  },
  {
    id: "body-therapy",
    name: "Golden Elixir Velvet Body Glow",
    category: "body",
    categoryLabel: "BODY GLOW",
    description: "Exquisite full-body exfoliation, rich botanical wrap, and hydration therapy that leaves standard skin unbelievably soft.",
    price: "₹9,500",
    duration: "100 mins",
    iconName: "Droplet"
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: "gallery-balayage",
    src: "https://lh3.googleusercontent.com/aida-public/AB6AXuCHyxT98TmRlqMcM_-7ShL0hqAdtNuOCC8w6MICXAPhph1PTx9ze2GXVYoBh0erwSEh4veRcA5OlrAc0ad_vf08Dt7E_RKRhbt9vTfyVjMTz6ZKgpGL2peSSuyZ8wOvK882wzodOelqxZ4THXJNgIIqT4BDEl3aiMCpVYH0Y3oz_H_q3GPCOF3akKGSHhfyFa3gmAmnYj2oQFxtfhf6CaAeNLNPogjNWOj3sRN3fCnMch7dXHol8xJ14xOpNWr9u_e22PtUOIAMnw",
    category: "color",
    title: "Signature Ash-Blonde Balayage",
    description: "Sunkissed transition painted in layers to capture soft salon highlights."
  },
  {
    id: "gallery-bridal",
    src: "https://lh3.googleusercontent.com/aida-public/AB6AXuC52C-_PmR2KbcurFe3_JKv5ei8oAlU9dudHQNM5bls5TRLALKNNXgGJzzyxlq8GSbhOAIZq3Fvgt8L7LRhezSMmJ_zdaNB_az2KmKkhg8urWfIWMW6aphjkYVQ-2S-mXHcYCZM-Cy8TyFBFUxTP797axS0DxnqFEQgUldW91zP0AwnvHpGd-si5i4b7-YuTEYb5Tsn6vapyKmzBaQMSy3ScVeynAQ2DRMIUYs6kO-o5wNPcO-1b7nS-mfD-Q8xFbHINnG8ATsyTg",
    category: "bridal",
    title: "Luminous Bridal Glamour",
    description: "High-definition bridal couture tailored for custom wedding ceremonies."
  },
  {
    id: "gallery-styling",
    src: "https://lh3.googleusercontent.com/aida-public/AB6AXuBFgJFueEHnONE7s-VDv3YOC9OsJYYeRQl7kEJv1_riNBVN3djhN6JQaLaL0Ipj-N18TCg5WNkSF0UHbl2ffccb2A90hj6CDP13YAf7HRyIF0W8ATL39fpO5olVZJpUv447KkuUBer5dcs3Pd4WcXrOMOH2Grg0FUa-m-40eomz8uofaPnBGWGJlERVCu3otqU5bniu_FrokXLdjOj9uZrnWYddC2SooEp4zNpmTh7STNRBUesuiCF9E-XipvP9DvJ7sO6G2qgAQw",
    category: "styling",
    title: "Bespoke Hair Sculpting & Updo",
    description: "Intricately styled formal updo demonstrating precision hold."
  },
  {
    id: "gallery-brunette",
    src: "https://lh3.googleusercontent.com/aida-public/AB6AXuB9tbtKpDPgO_NImzQCnkzfIDSu0TlLn8Po4yp-s6HhPsyg6EmH8iGi0rKdY-09rhQN0F3R8sbDoEX0eBBsTKmurtF0gNHZs5JKeJCKw2lO3dAcT1lrr2RS5SOJYqZKQwEXMlP_q2eK0GyUOLLir7-NikX6SwKK8P8ZsHbUuLSERVsTzBFJWJU23qNiNPJjw5twV_eFZPU5iRz-9W9ZHqxDkCfXXFFbvmvJN_WED77ZzPLHjVtFydEhN8EctmDj9qmrk0CiYiT2kg",
    category: "color",
    title: "Glossy Imperial Brunette",
    description: "Glistening warm gloss reflecting flawless texture and luster."
  },
  {
    id: "gallery-skincare",
    src: "https://lh3.googleusercontent.com/aida-public/AB6AXuAgDgVoMLiZpiIxu2BiBXdiLpnhAFMTPRVVpozOz0Ny_Mf8vlqyduafgF1pW6keSGFSBXavLsxAQgv5LUhwHIowlB9TliDyH1L9sFdgie0xAD1wbA3U2CYmXS41093PdxL5alZJvFAbXogxDEolGva0UkgxBEh78B8jkvYMzpPumTLHVqLCJrEFGweQgSO0YkhXBgsEjkDZpVHnTjxGoFRPTCyEmAjhpi3i5pNjbX2Z5zpHA7jat4sOMnWUCfI_8GXmlLKN1KGEGA",
    category: "facials",
    title: "Dermal Hydration Treatment",
    description: "Tranquil facial spa using state-of-the-art oxygen-infusion therapies."
  }
];

export const REVIEWS: Review[] = [
  {
    id: "review-1",
    author: "Priya Sharma",
    role: "LIFESTYLE BLOGGER",
    rating: 5,
    comment: "The attention to detail at Strivenii is unparalleled. I've never had a stylist take the time to understand my hair texture so deeply. Truly Mumbai's best salon.",
    avatarColor: "bg-primary-container/20"
  },
  {
    id: "review-2",
    author: "Ananya Malhotra",
    role: "BRIDE",
    rating: 5,
    comment: "My bridal makeover was exactly what I dreamed of. They made me feel like royalty and the makeup lasted beautifully through all the ceremonies.",
    avatarColor: "bg-secondary-container/30"
  },
  {
    id: "review-3",
    author: "Rohan Verma",
    role: "CREATIVE DIRECTOR",
    rating: 5,
    comment: "The spa rituals are a lifesaver. It's the only place in the city where I can truly disconnect and recharge in a completely hygienic environment.",
    avatarColor: "bg-tertiary-container/30"
  }
];

export const AVAILABLE_SLOTS = [
  "10:00 AM",
  "11:00 AM",
  "12:00 PM",
  "01:00 PM",
  "02:00 PM",
  "03:00 PM",
  "04:00 PM",
  "05:00 PM",
  "06:00 PM",
  "07:00 PM"
];
