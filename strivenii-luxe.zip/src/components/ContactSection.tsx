import React from 'react';
import { MapPin, Clock, Phone, Mail, Navigation } from 'lucide-react';
import { MAP_IMAGE } from '../data';

export default function ContactSection() {
  return (
    <section id="contact" className="py-16 md:py-24 bg-background scroll-smooth">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center animate-fade-in">
          
          <div>
            <span className="font-sans text-xs uppercase tracking-[0.3em] font-bold text-primary block mb-3">
              Visit Us
            </span>
            <h2 className="font-serif text-3xl md:text-5xl font-semibold text-on-surface mb-8 leading-tight">
              The Salon in Goregaon
            </h2>
            <div className="rose-gold-gradient-line mb-10 w-24"></div>

            <div className="space-y-8">
              
              <div className="flex items-start space-x-6 group">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                  <MapPin size={18} />
                </div>
                <div>
                  <h4 className="font-serif text-lg font-semibold text-on-surface mb-1">
                    Address
                  </h4>
                  <p className="text-on-surface-variant font-sans text-sm leading-relaxed">
                    Shop 4, Luxury Towers, S.V. Road,<br />Goregaon West, Mumbai, Maharashtra 400104
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-6 group">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                  <Clock size={18} />
                </div>
                <div>
                  <h4 className="font-serif text-lg font-semibold text-on-surface mb-1">
                    Business Hours
                  </h4>
                  <p className="text-on-surface-variant font-sans text-sm leading-relaxed">
                    Mon - Sat: 10:00 AM - 9:00 PM<br />Sun: 11:00 AM - 7:00 PM
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-6 group">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all">
                  <Mail size={18} />
                </div>
                <div>
                  <h4 className="font-serif text-lg font-semibold text-on-surface mb-1">
                    Connect
                  </h4>
                  <p className="text-on-surface-variant font-sans text-sm leading-relaxed">
                    hello@strivenii.com<br />+91 98200 12345
                  </p>
                </div>
              </div>

            </div>

            <div className="pt-8">
              <a
                href="https://maps.google.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2 bg-primary text-white py-3 px-6 rounded-full font-sans text-xs uppercase tracking-widest font-semibold hover:bg-primary/95 transition-all shadow-md"
              >
                <Navigation size={14} />
                <span>Get Directions</span>
              </a>
            </div>
          </div>

          <div className="relative group rounded-2xl overflow-hidden shadow-2xl border border-outline-variant/30 aspect-auto h-[350px] sm:h-[450px]">
            <img
              src={MAP_IMAGE}
              alt="Goregaon West Mumbai Map"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-102"
            />
            {/* Elegant luxury pin overlay */}
            <div className="absolute top-[48%] left-[45%] flex flex-col items-center">
              <div className="relative">
                <div className="w-6 h-6 rounded-full bg-primary border-2 border-white animate-ping absolute inset-0"></div>
                <div className="w-6 h-6 rounded-full bg-primary border-2 border-white flex items-center justify-center text-white relative z-10 shadow-lg">
                  <span className="w-1.5 h-1.5 bg-white rounded-full"></span>
                </div>
              </div>
              <span className="mt-1.5 bg-on-background/90 text-primary-fixed text-[10px] tracking-wider py-1 px-2.5 rounded-lg font-semibold border border-white/20 whitespace-nowrap shadow-md">
                Strivenii Luxury Salon
              </span>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
