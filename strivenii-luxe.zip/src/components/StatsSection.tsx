import React from 'react';
import { ShieldAlert, Sparkles, Award } from 'lucide-react';

export default function StatsSection() {
  const stats = [
    { value: '1,429+', label: 'Happy Clients' },
    { value: '15+', label: 'Expert Stylists' },
    { value: '4.9', label: 'Avg. Rating' },
    { value: '12k+', label: 'Services Done' },
  ];

  return (
    <section className="py-16 md:py-24 relative bg-on-background text-white overflow-hidden scroll-smooth">
      {/* Soft glowing ambient circles */}
      <div className="absolute top-1/2 left-1/4 w-[300px] h-[300px] md:w-[500px] md:h-[500px] bg-primary/20 rounded-full blur-[90px] md:blur-[120px] -translate-y-1/2 -z-10 bg-blend-screen"></div>
      <div className="absolute bottom-0 right-10 w-[200px] h-[200px] bg-primary-container/10 rounded-full blur-[80px] -z-10"></div>

      <div className="max-w-7xl mx-auto px-5 md:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <div>
            <span className="font-sans text-xs uppercase tracking-[0.3em] font-bold text-primary-fixed block mb-3">
              The Distinction
            </span>
            <h2 className="font-serif text-3xl md:text-5xl font-semibold mb-6 leading-tight">
              Unparalleled Standards of Excellence
            </h2>
            <div className="w-16 h-[1px] bg-primary-fixed-dim mb-8"></div>
            <p className="font-sans text-sm md:text-base text-white/70 leading-relaxed mb-12">
              We combine renowned global beauty standards with deeply intimate, personalized care to create a sacred sanctuary of pure luxury in Goregaon West, Mumbai.
            </p>

            <div className="space-y-10">
              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 flex-shrink-0 border border-primary-fixed/30 rounded-full flex items-center justify-center bg-white/5">
                  <ShieldAlert className="text-primary-fixed w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-serif text-xl font-medium text-white mb-1">
                    Hygienic Environment
                  </h4>
                  <p className="text-white/60 font-sans text-sm leading-relaxed">
                    Medical-grade sterilization protocols and personalized single-use kits for every client interaction.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="w-12 h-12 flex-shrink-0 border border-primary-fixed/30 rounded-full flex items-center justify-center bg-white/5">
                  <Award className="text-primary-fixed w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-serif text-xl font-medium text-white mb-1">
                    Premium Products
                  </h4>
                  <p className="text-white/60 font-sans text-sm leading-relaxed">
                    Exclusive partnerships with world-renowned luxurious brands such as L'Oréal Professionnel and Kérastase.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 md:gap-8 pt-6 lg:pt-0">
            {stats.map((stat, idx) => (
              <div
                key={idx}
                className={`glass-dark p-8 md:p-10 rounded-2xl text-center hover:translate-y-[-4px] transition-transform duration-300 ${
                  idx % 2 === 1 ? 'mt-6 sm:mt-10' : ''
                }`}
              >
                <span className="block text-4xl md:text-5xl font-serif font-bold text-primary-fixed mb-2">
                  {stat.value}
                </span>
                <span className="font-sans text-xs uppercase tracking-widest text-white/50 font-semibold block">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
