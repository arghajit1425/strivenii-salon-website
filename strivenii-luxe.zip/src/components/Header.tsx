import React, { useState, useEffect } from 'react';
import { Menu, X, Calendar, Phone } from 'lucide-react';

interface HeaderProps {
  onBookClick: () => void;
  onCallClick: () => void;
}

export default function Header({ onBookClick, onCallClick }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Home', href: '#home' },
    { label: 'Services', href: '#services' },
    { label: 'Bridal', href: '#bridal' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'About', href: '#about' },
    { label: 'Contact', href: '#contact' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        id="app-header"
        className={`fixed top-0 w-full z-50 h-20 transition-all duration-300 ${
          isScrolled
            ? 'bg-surface/90 backdrop-blur-xl border-b border-primary/10 shadow-lg'
            : 'bg-transparent border-b border-white/10'
        }`}
      >
        <div className="flex justify-between items-center w-full px-5 md:px-8 max-w-7xl mx-auto h-full">
          <a
            href="#home"
            className={`font-serif text-3xl font-bold italic tracking-tighter ${
              isScrolled ? 'text-primary' : 'text-white md:text-primary'
            }`}
            onClick={(e) => handleNavClick(e, '#home')}
          >
            Strivenii
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={(e) => handleNavClick(e, item.href)}
                className={`font-sans text-xs uppercase tracking-widest font-semibold transition-all duration-300 hover:text-primary ${
                  isScrolled ? 'text-on-surface-variant' : 'text-white/90 hover:text-white'
                }`}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <button
              id="header-cta-book"
              onClick={onBookClick}
              className="bg-primary text-white hover:bg-primary/90 px-6 py-2.5 rounded-full font-sans text-xs uppercase tracking-wider font-semibold active:scale-95 transition-all cursor-pointer shadow-md"
            >
              Book Now
            </button>
          </div>

          {/* Mobile hamburger menu */}
          <button
            id="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg text-primary focus:outline-none"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </header>

      {/* Mobile Drawer Slide-in */}
      <div
        id="mobile-nav-drawer"
        className={`fixed inset-0 z-40 bg-on-background/40 backdrop-blur-sm transition-opacity duration-300 md:hidden ${
          mobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setMobileMenuOpen(false)}
      >
        <div
          className={`absolute top-0 right-0 w-3/4 max-w-sm h-full bg-surface p-8 shadow-2xl transition-transform duration-300 flex flex-col justify-between ${
            mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="space-y-8 pt-12">
            <div className="font-serif text-3xl italic tracking-tighter text-primary">
              Strivenii
            </div>
            <div className="rose-gold-gradient-line w-full"></div>
            <nav className="flex flex-col space-y-6">
              {navItems.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  onClick={(e) => handleNavClick(e, item.href)}
                  className="font-sans text-sm uppercase tracking-widest font-semibold text-on-surface hover:text-primary transition-colors"
                >
                  {item.label}
                </a>
              ))}
            </nav>
          </div>

          <div className="space-y-4">
            <button
              id="drawer-book-btn"
              onClick={() => {
                setMobileMenuOpen(false);
                onBookClick();
              }}
              className="w-full bg-primary text-white py-3.5 rounded-full font-sans text-xs uppercase tracking-wider font-semibold flex items-center justify-center space-x-2"
            >
              <Calendar size={14} />
              <span>Book Appointment</span>
            </button>
            <button
              id="drawer-call-btn"
              onClick={() => {
                setMobileMenuOpen(false);
                onCallClick();
              }}
              className="w-full border border-primary text-primary py-3.5 rounded-full font-sans text-xs uppercase tracking-wider font-semibold flex items-center justify-center space-x-2 bg-white"
            >
              <Phone size={14} />
              <span>Call Now</span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
