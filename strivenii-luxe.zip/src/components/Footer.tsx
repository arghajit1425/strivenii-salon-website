import React, { useState } from 'react';
import { Share2, Camera, Send, Check } from 'lucide-react';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribed(true);
    setTimeout(() => {
      setEmail('');
      setSubscribed(false);
    }, 3000);
  };

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (href.startsWith('#')) {
      e.preventDefault();
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <footer className="bg-surface-container border-t border-outline-variant/30 scroll-smooth">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-12 py-16 md:py-20 px-5 md:px-8 max-w-7xl mx-auto">
        <div className="space-y-6">
          <span className="font-serif text-3xl text-primary italic font-bold tracking-tighter mb-4 block">
            Strivenii
          </span>
          <p className="text-on-surface-variant/80 font-sans text-sm leading-relaxed mb-6">
            Redefining beauty through the lens of modern luxury and personalized care. Handcrafted wellness in Mumbai.
          </p>
          <div className="flex space-x-4">
            <a
              href="#"
              className="w-10 h-10 rounded-full border border-primary/20 flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-all shadow-sm"
              aria-label="Share"
            >
              <Share2 size={16} />
            </a>
            <a
              href="#"
              className="w-10 h-10 rounded-full border border-primary/20 flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-all shadow-sm"
              aria-label="Instagram"
            >
              <Camera size={16} />
            </a>
          </div>
        </div>

        <div>
          <h4 className="font-sans text-sm font-bold text-on-surface uppercase tracking-widest mb-6">
            Quick Links
          </h4>
          <ul className="space-y-4 font-sans text-xs uppercase tracking-widest font-semibold">
            <li>
              <a
                href="#services"
                onClick={(e) => handleLinkClick(e, '#services')}
                className="text-on-surface-variant/80 hover:text-primary transition-colors block"
              >
                Services
              </a>
            </li>
            <li>
              <a
                href="#bridal"
                onClick={(e) => handleLinkClick(e, '#bridal')}
                className="text-on-surface-variant/80 hover:text-primary transition-colors block"
              >
                Bridal Packages
              </a>
            </li>
            <li>
              <a
                href="#gallery"
                onClick={(e) => handleLinkClick(e, '#gallery')}
                className="text-on-surface-variant/80 hover:text-primary transition-colors block"
              >
                Transformation Gallery
              </a>
            </li>
            <li>
              <a
                href="#"
                className="text-on-surface-variant/80 hover:text-primary transition-colors block"
              >
                Gift Cards
              </a>
            </li>
          </ul>
        </div>

        <div>
          <h4 className="font-sans text-sm font-bold text-on-surface uppercase tracking-widest mb-6">
            Information
          </h4>
          <ul className="space-y-4 font-sans text-xs uppercase tracking-widest font-semibold">
            <li>
              <a
                href="#"
                className="text-on-surface-variant/80 hover:text-primary transition-colors block"
              >
                Privacy Policy
              </a>
            </li>
            <li>
              <a
                href="#"
                className="text-on-surface-variant/80 hover:text-primary transition-colors block"
              >
                Terms of Service
              </a>
            </li>
            <li>
              <a
                href="#"
                className="text-on-surface-variant/80 hover:text-primary transition-colors block"
              >
                Sustainability
              </a>
            </li>
            <li>
              <a
                href="#"
                className="text-on-surface-variant/80 hover:text-primary transition-colors block"
              >
                Careers
              </a>
            </li>
          </ul>
        </div>

        <div className="space-y-6">
          <h4 className="font-sans text-sm font-bold text-on-surface uppercase tracking-widest">
            Newsletter
          </h4>
          <p className="text-xs text-on-surface-variant leading-relaxed">
            Join our elite circle for exclusive beauty tips and early access to promotions.
          </p>

          <form onSubmit={handleSubscribe} className="relative">
            {subscribed ? (
              <div className="bg-primary/10 border border-primary/20 rounded-full py-3 px-6 text-xs text-primary font-semibold flex items-center space-x-2 animate-fade-in">
                <Check size={14} />
                <span>You are in our Elite Circle.</span>
              </div>
            ) : (
              <>
                <input
                  required
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address"
                  className="w-full bg-white border border-outline-variant/50 rounded-full py-3 px-6 pr-12 text-xs text-on-surface focus:ring-1 focus:ring-primary focus:border-primary focus:outline-none"
                />
                <button
                  type="submit"
                  className="absolute right-1.5 top-1.5 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center hover:bg-primary/90 transition-colors cursor-pointer"
                  aria-label="Subscribe"
                >
                  <Send size={12} />
                </button>
              </>
            )}
          </form>
        </div>
      </div>

      <div className="border-t border-outline-variant/10 py-8 px-5 md:px-8 max-w-7xl mx-auto text-center">
        <p className="font-sans text-xs text-on-surface-variant/60">
          © {new Date().getFullYear()} Strivenii Hair and Beauty. All Rights Reserved.
        </p>
      </div>
    </footer>
  );
}
