import React, { useState } from 'react';
import { GALLERY_ITEMS } from '../data';
import { ZoomIn, ArrowRight, X, Heart, ShieldAlert } from 'lucide-react';

export default function GallerySection() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeImageId, setActiveImageId] = useState<string | null>(null);
  const [likes, setLikes] = useState<Record<string, number>>({});
  const [likedList, setLikedList] = useState<Record<string, boolean>>({});

  const categories = [
    { value: 'all', label: 'All Work' },
    { value: 'color', label: 'Color Artistry' },
    { value: 'bridal', label: 'Bridal Couture' },
    { value: 'styling', label: 'Precision Styling' },
    { value: 'facials', label: 'Active Skincare' },
  ];

  const filteredItems = selectedCategory === 'all'
    ? GALLERY_ITEMS
    : GALLERY_ITEMS.filter(item => item.category === selectedCategory);

  const activeImage = GALLERY_ITEMS.find(item => item.id === activeImageId);

  const toggleLike = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const isLiked = likedList[id];
    setLikedList(prev => ({ ...prev, [id]: !isLiked }));
    setLikes(prev => ({
      ...prev,
      [id]: (prev[id] || 0) + (isLiked ? -1 : 1)
    }));
  };

  return (
    <section id="gallery" className="py-16 md:py-24 bg-background scroll-smooth">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 gap-6">
          <div className="max-w-xl">
            <span className="font-sans text-xs uppercase tracking-[0.3em] font-bold text-primary block mb-3">
              The Portfolio
            </span>
            <h2 className="font-serif text-3xl md:text-5xl font-semibold text-on-surface leading-tight">
              Stunning Transformations
            </h2>
            <div className="h-[1px] bg-primary/20 w-16 mt-4"></div>
          </div>

          <a
            href="https://instagram.com"
            target="_blank"
            rel="noopener noreferrer"
            className="font-sans text-xs uppercase tracking-widest font-semibold text-primary flex items-center space-x-2 group hover:text-primary/70 transition-colors"
          >
            <span>Follow Us @Strivenii</span>
            <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
          </a>
        </div>

        {/* Categories Tab Selector */}
        <div className="flex flex-wrap items-center gap-2 mb-10 pb-2 border-b border-primary/5">
          {categories.map((cat) => (
            <button
              id={`tab-category-${cat.value}`}
              key={cat.value}
              onClick={() => setSelectedCategory(cat.value)}
              className={`px-5 py-2.5 rounded-full font-sans text-xs uppercase tracking-wider font-semibold transition-all duration-300 ${
                selectedCategory === cat.value
                  ? 'bg-primary text-white shadow-md shadow-primary/10'
                  : 'bg-surface-container-low text-on-surface-variant hover:bg-surface-container-high hover:text-primary'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6">
          {filteredItems.map((item) => (
            <div
              id={`gallery-item-${item.id}`}
              key={item.id}
              onClick={() => setActiveImageId(item.id)}
              className="break-inside-avoid group relative overflow-hidden rounded-2xl cursor-pointer bg-surface border border-primary/5 shadow-sm hover:shadow-xl transition-all duration-500"
            >
              <img
                src={item.src}
                alt={item.title}
                className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
              />
              
              {/* Overlay on Hover */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-between p-6">
                <div className="flex justify-between items-center w-full">
                  <span className="bg-primary/90 text-white text-[10px] tracking-widest uppercase font-sans font-semibold py-1 px-2.5 rounded-full">
                    {item.category.toUpperCase()}
                  </span>
                  <button
                    onClick={(e) => toggleLike(e, item.id)}
                    className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md flex items-center justify-center text-white transition-all"
                  >
                    <Heart
                      size={15}
                      className={likedList[item.id] ? 'fill-red-500 text-red-500' : 'text-white'}
                    />
                  </button>
                </div>

                <div>
                  <h3 className="font-serif text-lg text-white mb-1 font-medium">{item.title}</h3>
                  <p className="font-sans text-xs text-white/80 leading-relaxed mb-3">{item.description}</p>
                  <div className="flex items-center space-x-1.5 text-primary-fixed text-xs font-semibold">
                    <ZoomIn size={14} />
                    <span>Expand Transformation</span>
                    {likes[item.id] ? <span className="ml-2 text-[10px] text-white/60">({likes[item.id]} loved)</span> : null}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {activeImage && (
        <div
          id="gallery-lightbox-modal"
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setActiveImageId(null)}
        >
          <div
            className="relative max-w-4xl w-full bg-on-background border border-white/10 rounded-2xl overflow-hidden flex flex-col md:flex-row max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top Close bar is useful */}
            <button
              id="lightbox-close-btn"
              onClick={() => setActiveImageId(null)}
              className="absolute top-4 right-4 z-50 bg-black/60 rounded-full p-2 text-white hover:bg-primary transition-colors cursor-pointer"
            >
              <X size={20} />
            </button>

            <div className="md:w-3/5 bg-black flex items-center justify-center overflow-hidden">
              <img
                src={activeImage.src}
                alt={activeImage.title}
                className="w-full h-full max-h-[60vh] md:max-h-[85vh] object-contain"
              />
            </div>

            <div className="md:w-2/5 p-8 flex flex-col justify-between text-white bg-on-background">
              <div>
                <span className="text-primary-fixed text-xs tracking-widest uppercase font-bold block mb-4">
                  {activeImage.category.toUpperCase()} ARTISTRY
                </span>
                <h3 className="font-serif text-2xl font-semibold mb-4 text-primary-fixed leading-snug">
                  {activeImage.title}
                </h3>
                <div className="h-[1px] bg-primary/25 w-16 mb-6"></div>
                <p className="font-sans text-sm text-white/80 leading-relaxed mb-6">
                  {activeImage.description}
                </p>
                <p className="font-sans text-xs text-white/60 leading-relaxed mb-4">
                  This signature service represents a harmonious dialogue between modern opulence and our customized clinical standards. Tested by our master expert artists in Mumbai.
                </p>
              </div>

              <div className="pt-6 border-t border-white/10 flex items-center justify-between">
                <div>
                  <span className="block text-[10px] uppercase tracking-wider text-white/50">Styled In</span>
                  <span className="block font-sans text-sm font-semibold">Goregaon West, Mumbai</span>
                </div>
                <button
                  onClick={(e) => toggleLike(e, activeImage.id)}
                  className="flex items-center space-x-2 bg-white/5 border border-white/10 py-2.5 px-4 rounded-full text-xs font-semibold hover:bg-white/10 transition-all text-primary-fixed"
                >
                  <Heart size={14} className={likedList[activeImage.id] ? 'fill-red-500 text-red-500' : ''} />
                  <span>{likedList[activeImage.id] ? 'Transformation Saved' : 'Love this look'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
