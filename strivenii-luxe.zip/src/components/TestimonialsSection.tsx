import React, { useState } from 'react';
import { REVIEWS } from '../data';
import { Star, MessageSquarePlus, CheckCircle2 } from 'lucide-react';
import { Review } from '../types';

export default function TestimonialsSection() {
  const [reviews, setReviews] = useState<Review[]>(REVIEWS);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  
  // Submit review state
  const [newAuthor, setNewAuthor] = useState('');
  const [newRole, setNewRole] = useState('CLIENT');
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [hasSubmitted, setHasSubmitted] = useState(false);

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor.trim() || !newComment.trim()) return;

    const addedReview: Review = {
      id: `review-custom-${Date.now()}`,
      author: newAuthor,
      role: newRole.toUpperCase() || 'LIFESTYLE GUEST',
      rating: newRating,
      comment: newComment,
      avatarColor: 'bg-primary-container/20'
    };

    setReviews(prev => [addedReview, ...prev]);
    setHasSubmitted(true);
    setTimeout(() => {
      setShowSubmitModal(false);
      setHasSubmitted(false);
      // reset fields
      setNewAuthor('');
      setNewRole('CLIENT');
      setNewRating(5);
      setNewComment('');
    }, 1800);
  };

  return (
    <section className="py-16 md:py-24 bg-surface-container overflow-hidden scroll-smooth">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="text-center mb-12 md:mb-16">
          <span className="font-sans text-xs uppercase tracking-[0.3em] font-bold text-primary block mb-3">
            Kind Words
          </span>
          <h2 className="font-serif text-3xl md:text-5xl font-semibold text-on-surface">
            Client Experiences
          </h2>
          <div className="rose-gold-gradient-line mt-6 w-24 mx-auto"></div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12 items-start">
          {reviews.map((review, idx) => (
            <div
              id={`review-card-${review.id}`}
              key={review.id}
              className={`bg-surface p-8 md:p-10 rounded-2xl shadow-sm border border-outline-variant/30 relative transition-transform duration-500 ${
                idx === 1 ? 'md:-mt-4 bg-white shadow-md' : ''
              }`}
            >
              <div className="flex text-yellow-500 mb-6">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    size={16}
                    className={i < review.rating ? 'fill-current text-yellow-400' : 'text-gray-200'}
                  />
                ))}
              </div>

              <p className="font-sans text-sm text-on-surface-variant italic mb-8 leading-relaxed">
                "{review.comment}"
              </p>

              <div className="flex items-center space-x-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs uppercase ${review.avatarColor} text-primary`}>
                  {review.author.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-on-surface font-sans text-sm">{review.author}</p>
                  <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-wider">{review.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA to submit review interactive */}
        <div className="text-center">
          <button
            id="write-review-btn"
            onClick={() => setShowSubmitModal(true)}
            className="inline-flex items-center space-x-2 border border-primary text-primary hover:bg-primary hover:text-white px-6 py-3 rounded-full font-sans text-xs uppercase tracking-widest font-semibold transition-all cursor-pointer bg-white/50"
          >
            <MessageSquarePlus size={14} />
            <span>Share Your Experience</span>
          </button>
        </div>
      </div>

      {/* Review Submission Modal Dialog */}
      {showSubmitModal && (
        <div
          id="review-submit-modal"
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setShowSubmitModal(false)}
        >
          <div
            className="bg-surface max-w-md w-full p-8 rounded-2xl shadow-2xl border border-primary/10 relative"
            onClick={(e) => e.stopPropagation()}
          >
            {hasSubmitted ? (
              <div className="text-center py-10 space-y-4">
                <CheckCircle2 size={48} className="text-primary mx-auto animate-bounce" />
                <h3 className="font-serif text-2xl font-semibold text-primary">Thank You!</h3>
                <p className="font-sans text-sm text-on-surface-variant">
                  Your luxury review has been recorded. It shines alongside Mumbai's most exclusive transformational portfolio.
                </p>
              </div>
            ) : (
              <form onSubmit={handleAddReview} className="space-y-6">
                <div>
                  <h3 className="font-serif text-2xl font-semibold text-primary">Your Experience</h3>
                  <p className="font-sans text-xs text-on-surface-variant mt-1">
                    Describe how the Strivenii touch refined your holistic beauty.
                  </p>
                </div>

                <div className="rose-gold-gradient-line w-full"></div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-on-surface-variant/80 font-bold mb-1.5">
                      Your Full Name
                    </label>
                    <input
                      required
                      type="text"
                      value={newAuthor}
                      onChange={(e) => setNewAuthor(e.target.value)}
                      placeholder="e.g. Meera Kapur"
                      className="w-full bg-white border border-outline-variant/50 rounded-lg p-3 text-sm focus:ring-1 focus:ring-primary focus:border-primary focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-wider text-on-surface-variant/80 font-bold mb-1.5">
                      Your Affiliation / Role
                    </label>
                    <input
                      type="text"
                      value={newRole}
                      onChange={(e) => setNewRole(e.target.value)}
                      placeholder="e.g. Guest / Lifestyle Specialist"
                      className="w-full bg-white border border-outline-variant/50 rounded-lg p-3 text-sm focus:ring-1 focus:ring-primary focus:border-primary focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-wider text-on-surface-variant/80 font-bold mb-1.5">
                      Experience Rating
                    </label>
                    <div className="flex items-center space-x-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setNewRating(star)}
                          className="text-yellow-400 p-0.5 focus:outline-none hover:scale-110 transition-transform"
                        >
                          <Star size={24} className={newRating >= star ? 'fill-current' : 'text-gray-200'} />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-wider text-on-surface-variant/80 font-bold mb-1.5">
                      Your Review Comment
                    </label>
                    <textarea
                      required
                      rows={3}
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      placeholder="Explain how our masters refined your hair or skin artistry..."
                      className="w-full bg-white border border-outline-variant/50 rounded-lg p-3 text-sm focus:ring-1 focus:ring-primary focus:border-primary focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowSubmitModal(false)}
                    className="flex-1 border border-outline py-2.5 rounded-full text-xs font-semibold text-on-surface-variant hover:bg-surface-container-low transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-primary text-white py-2.5 rounded-full text-xs font-semibold hover:bg-primary/90 transition-colors shadow-md"
                  >
                    Submit Review
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
