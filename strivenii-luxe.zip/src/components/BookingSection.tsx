import React, { useState, useEffect, useImperativeHandle, forwardRef } from 'react';
import { SERVICES, CTA_TOOLS_IMAGE, AVAILABLE_SLOTS } from '../data';
import { Sparkles, Calendar, Phone, CheckCircle2, ShoppingBag, X, MessageSquare } from 'lucide-react';
import { Booking } from '../types';

interface BookingSectionProps {
  selectedServiceId: string;
  onBookingCreated: (booking: Booking) => void;
}

export interface BookingSectionRef {
  focusSection: () => void;
}

const BookingSection = forwardRef<BookingSectionRef, BookingSectionProps>(
  ({ selectedServiceId, onBookingCreated }, ref) => {
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [serviceId, setServiceId] = useState('Select Service');
    const [date, setDate] = useState('');
    const [timeSlot, setTimeSlot] = useState('');
    const [notes, setNotes] = useState('');
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [activeBookings, setActiveBookings] = useState<Booking[]>([]);
    const [showBookingsPanel, setShowBookingsPanel] = useState(false);

    // Sync selected service if changed from outside
    useEffect(() => {
      if (selectedServiceId) {
        setServiceId(selectedServiceId);
      }
    }, [selectedServiceId]);

    // Handle scroll block focus
    useImperativeHandle(ref, () => ({
      focusSection: () => {
        const element = document.getElementById('booking-section');
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      },
    }));

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!name.trim() || !phone.trim() || serviceId === 'Select Service' || !date || !timeSlot) {
        alert('Please complete all fields to secure your booking.');
        return;
      }

      const selectedServiceObj = SERVICES.find((s) => s.id === serviceId);
      const serviceName = selectedServiceObj ? selectedServiceObj.name : 'Custom Sanctuary Treatment';
      const servicePrice = selectedServiceObj ? selectedServiceObj.price : '₹3,500';

      const newBooking: Booking = {
        id: `booking-${Date.now()}`,
        name,
        phone,
        serviceId,
        serviceName,
        date,
        timeSlot,
        notes,
        createdAt: new Date().toLocaleDateString(),
        price: servicePrice,
      };

      // Add to local state
      setActiveBookings((prev) => [newBooking, ...prev]);
      onBookingCreated(newBooking);
      setIsSubmitted(true);
    };

    const handleCancelBooking = (id: string) => {
      setActiveBookings((prev) => prev.filter((b) => b.id !== id));
    };

    const resetForm = () => {
      setName('');
      setPhone('');
      setServiceId('Select Service');
      setDate('');
      setTimeSlot('');
      setNotes('');
      setIsSubmitted(false);
    };

    // Calculate dynamic next 5 days for "The Calendar" quick selection
    const getNextDays = () => {
      const days = [];
      const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      for (let i = 0; i < 6; i++) {
        const d = new Date();
        d.setDate(d.getDate() + i);
        days.push({
          fullDate: d.toISOString().split('T')[0],
          dayName: weekdays[d.getDay()],
          dayNum: d.getDate(),
        });
      }
      return days;
    };

    const quickDays = getNextDays();

    return (
      <section id="booking-section" className="py-16 md:py-24 relative scroll-smooth">
        <div className="max-w-7xl mx-auto px-5 md:px-8">
          <div className="bg-primary/5 rounded-3xl p-8 md:p-16 lg:p-20 overflow-hidden relative border border-primary/10 shadow-lg">
            
            {/* Split structure, with luxury arrangements image on desktop */}
            <div className="absolute top-0 right-0 w-1/2 h-full hidden lg:block">
              <img
                src={CTA_TOOLS_IMAGE}
                alt="Luxury beauty tools"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-transparent"></div>
            </div>

            <div className="max-w-xl relative z-10">
              <div className="flex items-center space-x-2 mb-4">
                <Sparkles size={16} className="text-primary" />
                <span className="text-xs uppercase tracking-[0.2em] font-bold text-primary">
                  The Sanctuary Appointment
                </span>
              </div>

              <h2 className="font-serif text-3xl md:text-5xl font-semibold text-primary mb-6 leading-tight">
                Secure Your Experience
              </h2>
              <p className="font-sans text-sm md:text-base text-on-surface-variant mb-8 leading-relaxed">
                Our calendar fills up quickly. Choose your desired slots directly below or reach out for custom packages via WhatsApp.
              </p>

              {/* View Active Appointments Button if any exist */}
              {activeBookings.length > 0 && (
                <button
                  type="button"
                  id="view-active-appointments-btn"
                  onClick={() => setShowBookingsPanel(true)}
                  className="mb-8 inline-flex items-center space-x-2 bg-primary/10 text-primary py-2 px-4 rounded-full text-xs font-semibold hover:bg-primary/20 transition-all border border-primary/10 cursor-pointer"
                >
                  <ShoppingBag size={14} />
                  <span>You have {activeBookings.length} session(s) booked. View details</span>
                </button>
              )}

              {isSubmitted ? (
                <div id="booking-success-box" className="bg-white/80 border border-primary/20 rounded-2xl p-8 text-center space-y-6 animate-fade-in shadow-lg">
                  <CheckCircle2 size={48} className="text-primary mx-auto animate-bounce animate-duration-1000" />
                  <div>
                    <h3 className="font-serif text-2xl font-semibold text-primary">Bespoke Session Secured</h3>
                    <p className="font-sans text-xs text-on-surface-variant mt-2 max-w-sm mx-auto">
                      Dear <strong>{name}</strong>, your spot on <strong>{date}</strong> at <strong>{timeSlot}</strong> is reserved at Goregaon West.
                    </p>
                  </div>
                  <div className="bg-primary/5 p-4 rounded-xl max-w-xs mx-auto text-left space-y-2 border border-primary/10">
                    <div className="flex justify-between text-xs font-semibold text-on-surface">
                      <span>Service:</span>
                      <span className="text-primary truncate max-w-[150px]">
                        {SERVICES.find((s) => s.id === serviceId)?.name || 'Opulent Style'}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs font-semibold text-on-surface">
                      <span>Time:</span>
                      <span>{timeSlot}</span>
                    </div>
                    <div className="flex justify-between text-xs font-semibold text-on-surface">
                      <span>Ref Price:</span>
                      <span className="font-serif text-primary">{SERVICES.find((s) => s.id === serviceId)?.price || 'Custom'}</span>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <button
                      type="button"
                      onClick={resetForm}
                      className="flex-1 bg-primary text-white py-3 rounded-full font-sans text-xs uppercase tracking-wider font-semibold hover:bg-primary/95 transition-all"
                    >
                      Book Another Slot
                    </button>
                    <a
                      href={`https://wa.me/919820012345?text=Hi%20Strivenii,%20I%20have%20booked%20a%20slot%20for%20${encodeURIComponent(name)}%20on%20${date}%20at%20${timeSlot}.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 border border-primary text-primary hover:bg-primary/5 py-3 rounded-full font-sans text-xs uppercase tracking-wider font-semibold text-center flex items-center justify-center space-x-2"
                    >
                      <MessageSquare size={14} />
                      <span>Confirm via WhatsApp</span>
                    </a>
                  </div>
                </div>
              ) : (
                <form id="booking-submission-form" onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="relative">
                      <input
                        required
                        type="text"
                        placeholder="Your Name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-white border-0 border-b border-primary/30 p-4 focus:ring-0 focus:border-primary transition-colors text-on-surface text-sm focus:outline-none"
                      />
                    </div>
                    <div className="relative">
                      <input
                        required
                        type="tel"
                        placeholder="Phone Number"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full bg-white border-0 border-b border-primary/30 p-4 focus:ring-0 focus:border-primary transition-colors text-on-surface text-sm focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="relative">
                      <select
                        value={serviceId}
                        onChange={(e) => setServiceId(e.target.value)}
                        className="w-full bg-white border-0 border-b border-primary/30 p-4 focus:ring-0 focus:border-primary transition-colors text-on-surface text-sm focus:outline-none cursor-pointer"
                      >
                        <option disabled value="Select Service">
                          Select Service
                        </option>
                        {SERVICES.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name} ({s.price})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="relative">
                      <input
                        required
                        type="date"
                        value={date}
                        min={new Date().toISOString().split('T')[0]}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full bg-white border-0 border-b border-primary/30 p-4 focus:ring-0 focus:border-primary transition-colors text-on-surface text-sm focus:outline-none cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Specialty component: Custom interactive Calendar quick date selection */}
                  <div>
                    <label className="block text-[10px] uppercase tracking-[0.1em] font-bold text-on-surface-variant/80 mb-3">
                      Or Quick Select Booking Day:
                    </label>
                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                      {quickDays.map((qd) => (
                        <button
                          key={qd.fullDate}
                          type="button"
                          onClick={() => setDate(qd.fullDate)}
                          className={`p-3 rounded-xl border flex flex-col items-center justify-center transition-all ${
                            date === qd.fullDate
                              ? 'border-primary bg-primary-container/10 text-primary font-semibold ring-1 ring-primary'
                              : 'border-primary/10 bg-white hover:bg-primary-container/5 text-on-surface-variant'
                          }`}
                        >
                          <span className="text-[10px] uppercase tracking-wider block opacity-70">
                            {qd.dayName}
                          </span>
                          <span className="text-base font-serif font-bold mt-1 block">
                            {qd.dayNum}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Specialty component: Time Slots Selector with Rose Gold indicators */}
                  <div>
                    <label className="block text-[10px] uppercase tracking-[0.1em] font-bold text-on-surface-variant/80 mb-3">
                      Available Time Slots:
                    </label>
                    <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                      {AVAILABLE_SLOTS.map((slot) => (
                        <button
                          key={slot}
                          type="button"
                          onClick={() => setTimeSlot(slot)}
                          className={`py-2 px-3 rounded-lg border text-xs text-center transition-all ${
                            timeSlot === slot
                              ? 'bg-primary text-white border-primary font-semibold shadow-md'
                              : 'border-primary/15 bg-white hover:bg-primary-container/10 text-on-surface'
                          }`}
                        >
                          {slot}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2">
                    <textarea
                      placeholder="Add any specific requirements (optional)..."
                      rows={2}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="w-full bg-white border-0 border-b border-primary/30 p-4 focus:ring-0 focus:border-primary transition-colors text-on-surface text-sm focus:outline-none"
                    />
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4 pt-4">
                    <button
                      type="submit"
                      id="booking-submit-btn"
                      className="bg-primary text-white hover:bg-primary/95 px-10 py-4 rounded-full font-sans text-xs uppercase tracking-widest font-bold flex-1 hover:shadow-lg transition-all active:scale-98 cursor-pointer"
                    >
                      Secure Booking
                    </button>
                    <a
                      href="https://wa.me/919820012345?text=Hi%20Strivenii,%20I'd%20like%20to%20inquire%20about%20booking%20a%20salon%20session."
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-[#25D366] text-white hover:shadow-lg px-8 py-4 rounded-full font-sans text-xs uppercase tracking-widest font-bold flex items-center justify-center space-x-2 transition-all active:scale-98"
                    >
                      <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                        <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.438 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884 0 2.225.569 3.946 1.694 5.46l-.994 3.635 3.789-.994z"></path>
                      </svg>
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Sliding Side Appointments list dialog screen */}
        {showBookingsPanel && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex justify-end" onClick={() => setShowBookingsPanel(false)}>
            <div
              className="bg-background max-w-md w-full h-full p-8 shadow-2xl flex flex-col justify-between overflow-y-auto animate-fade-in-left"
              onClick={(e) => e.stopPropagation()}
            >
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-serif text-2xl font-semibold text-primary">Your Booked Sessions</h3>
                  <button onClick={() => setShowBookingsPanel(false)} className="p-1 rounded-full hover:bg-primary/10 text-on-surface">
                    <X size={20} />
                  </button>
                </div>

                <div className="rose-gold-gradient-line w-full mb-6"></div>

                <div className="space-y-4">
                  {activeBookings.map((b) => (
                    <div key={b.id} className="bg-white p-5 rounded-xl border border-primary/10 space-y-3 shadow-sm relative">
                      <button
                        onClick={() => handleCancelBooking(b.id)}
                        className="absolute right-3 top-3 text-[10px] uppercase font-bold text-red-500 hover:text-red-700 hover:underline"
                        title="Cancel Booking"
                      >
                        Cancel
                      </button>

                      <div className="space-y-1">
                        <span className="bg-primary/10 text-primary text-[10px] tracking-widest uppercase font-semibold py-1 px-2.5 rounded-full inline-block">
                          SEMINALLY SECURED
                        </span>
                        <h4 className="font-serif text-lg font-medium pt-1 text-on-surface">
                          {b.serviceName}
                        </h4>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-xs text-on-surface-variant">
                        <div>
                          <span className="block font-bold">DATE</span>
                          <span className="block mt-0.5 font-semibold text-on-surface">{b.date}</span>
                        </div>
                        <div>
                          <span className="block font-bold">TIME</span>
                          <span className="block mt-0.5 font-semibold text-on-surface">{b.timeSlot}</span>
                        </div>
                      </div>

                      <div className="flex justify-between items-center pt-2 border-t border-primary/5">
                        <span className="text-xs text-on-surface-variant">Rate: <strong className="font-serif text-primary text-sm">{b.price}</strong></span>
                        <span className="text-[10px] text-green-600 font-bold">&#9679; Confirmed</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-6">
                <p className="text-[10px] text-on-surface-variant leading-relaxed text-center mb-4">
                  Changes to session times require 24h notification. Standard rates apply.
                </p>
                <button
                  type="button"
                  onClick={() => setShowBookingsPanel(false)}
                  className="w-full bg-primary text-white py-3 rounded-full font-sans text-xs uppercase tracking-widest font-bold"
                >
                  Close Manager
                </button>
              </div>
            </div>
          </div>
        )}
      </section>
    );
  }
);

export default BookingSection;
