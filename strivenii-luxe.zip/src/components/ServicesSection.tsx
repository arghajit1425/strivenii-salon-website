import React from 'react';
import { SERVICES } from '../data';
import * as Icons from 'lucide-react';

interface ServicesSectionProps {
  onSelectService: (serviceId: string) => void;
}

export default function ServicesSection({ onSelectService }: ServicesSectionProps) {
  // Direct helper mapping for icon names
  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case 'Scissors':
        return <Icons.Scissors className="text-primary text-3xl h-8 w-8" />;
      case 'Flower':
        return <Icons.Sparkles className="text-primary text-3xl h-8 w-8" />; // standard flower/spa substitute
      case 'Palette':
        return <Icons.Palette className="text-primary text-3xl h-8 w-8" />;
      case 'Sparkles':
        return <Icons.Sparkles className="text-primary text-3xl h-8 w-8" />;
      case 'Smile':
        return <Icons.Smile className="text-primary text-3xl h-8 w-8" />;
      case 'Droplet':
        return <Icons.Droplet className="text-primary text-3xl h-8 w-8" />;
      default:
        return <Icons.Sparkles className="text-primary text-3xl h-8 w-8" />;
    }
  };

  return (
    <section id="services" className="py-16 md:py-24 bg-surface-container-low scroll-smooth">
      <div className="max-w-7xl mx-auto px-5 md:px-8 text-center mb-12 md:mb-16">
        <span className="font-sans text-xs uppercase tracking-[0.3em] font-bold text-primary block mb-3">
          Exquisite Care
        </span>
        <h2 className="font-serif text-3xl md:text-5xl font-semibold text-on-surface leading-tight">
          Curated Services
        </h2>
        <div className="rose-gold-gradient-line mt-6 w-24 mx-auto"></div>
        <p className="font-sans text-sm text-on-surface-variant max-w-xl mx-auto mt-4">
          Experience world-class artistry tailored by masters. Click any service below to preselect it for your bespoke session.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES.map((service) => (
            <div
              id={`service-card-${service.id}`}
              key={service.id}
              className="glass p-8 md:p-10 rounded-2xl group hover:shadow-2xl transition-all duration-500 border border-white/50 flex flex-col justify-between hover:-translate-y-1 bg-white/40 cursor-pointer"
              onClick={() => onSelectService(service.id)}
            >
              <div>
                <div className="w-16 h-16 bg-primary-container/10 rounded-full flex items-center justify-center mb-8 group-hover:scale-110 transition-transform">
                  {renderIcon(service.iconName)}
                </div>
                <h3 className="font-serif text-2xl font-medium text-on-surface mb-3 group-hover:text-primary transition-colors">
                  {service.name}
                </h3>
                <p className="font-sans text-sm text-on-surface-variant leading-relaxed mb-6">
                  {service.description}
                </p>
              </div>

              <div className="pt-4 border-t border-primary/5 flex justify-between items-center">
                <span className="text-xs font-bold text-primary tracking-widest uppercase">
                  {service.categoryLabel}
                </span>
                <div className="text-right">
                  <span className="block font-serif text-lg font-semibold text-primary">{service.price}</span>
                  <span className="block text-[10px] uppercase tracking-wider text-on-surface-variant/60">{service.duration}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
