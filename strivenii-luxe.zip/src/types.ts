export interface Service {
  id: string;
  name: string;
  category: 'styling' | 'spa' | 'color' | 'bridal' | 'facials' | 'body';
  categoryLabel: string;
  description: string;
  price: string;
  duration: string;
  iconName: string;
}

export interface Review {
  id: string;
  author: string;
  role: string;
  rating: number;
  comment: string;
  avatarColor: string;
}

export interface GalleryItem {
  id: string;
  src: string;
  category: string;
  title: string;
  description: string;
}

export interface TimeSlot {
  time: string;
  available: boolean;
}

export interface Booking {
  id: string;
  name: string;
  phone: string;
  serviceId: string;
  serviceName: string;
  date: string;
  timeSlot: string;
  notes?: string;
  createdAt: string;
  price: string;
}
