import React, { useState, useRef } from 'react';
import Header from './components/Header';
import ServicesSection from './components/ServicesSection';
import StatsSection from './components/StatsSection';
import GallerySection from './components/GallerySection';
import TestimonialsSection from './components/TestimonialsSection';
import BookingSection, { BookingSectionRef } from './components/BookingSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';

import { HERO_IMAGE, ABOUT_IMAGE } from './data';
import { Star, Phone, MessageSquare, Heart, Sparkles, Scissors, UserCheck, CheckCircle2, X } from 'lucide-react';
import { Booking } from './types';

export default function App() {
  const [selectedServiceId, setSelectedServiceId] = useState<string>('');
  const [showCallModal, setShowCallModal] = useState(false);
  const [lastCreatedBooking, setLastCreatedBooking] = useState<Booking | null>(null);
  const [showBookingBannerAlert, setShowBookingBannerAlert] = useState(false);

  const bookingRef = useRef<BookingSectionRef>(null);

  const handleSelectService = (serviceId: string) => {
    setSelectedServiceId(serviceId);
    if (bookingRef.current) {
      bookingRef.current.focusSection();
    }
  };

  const handleBookingClick = () => {
    if (bookingRef.current) {
      bookingRef.current.focusSection();
    }
  };

  const handleCallClick = () => {
    setShowCallModal(true);
  };

  const handleBookingCreated = (booking: Booking) => {
    setLastCreatedBooking(booking);
    setShowBookingBannerAlert(true);
    // Auto dismissal of alert banner after 5 seconds
    setTimeout(() => {
      setShowBookingBannerAlert(false);
    }, 6000);
  };

  const handleMobileNavClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const element = document.getElementById(targetId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="bg-background text-on-surface font-sans antialiased pb-16 md:pb-0 scroll-smooth">
      
      {/* Dynamic Success Alert Banner */}
      {showBookingBannerAlert && lastCreatedBooking && (
        <div id="booking-created-banner" className="fixed top-24 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-md bg-white border border-primary/20 p-4 rounded-xl shadow-2xl flex items-start space-x-3.5 animate-fade-in">
          <CheckCircle2 className="text-primary mt-1 flex-shrink-0" size={20} />
          <div className="flex-1">
            <h4 className="text-xs font-bold text-primary uppercase tracking-widest">Appointment Reserved!</h4>
            <p className="text-[11px] text-on-surface-variant mt-0.5 font-semibold">
              {lastCreatedBooking.serviceName} scheduled for {lastCreatedBooking.date} at {lastCreatedBooking.timeSlot}.
            </p>
          </div>
          <button
            onClick={() => setShowBookingBannerAlert(false)}
            className="text-on-surface-variant/60 hover:text-on-surface hover:bg-primary/5 p-1 rounded-full"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* Styled Call Modal Dialog */}
      {showCallModal && (
        <div
          id="call-us-modal"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setShowCallModal(false)}
        >
          <div
            className="bg-surface border border-primary/10 max-w-sm w-full p-8 rounded-2xl shadow-2xl text-center space-y-6 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setShowCallModal(false)}
              className="absolute top-4 right-4 text-on-surface-variant/60 hover:text-on-surface"
            >
              <X size={20} />
            </button>

            <div className="w-16 h-16 bg-primary-container/10 rounded-full flex items-center justify-center mx-auto text-primary">
              <Phone size={28} className="animate-pulse" />
            </div>

            <div className="space-y-2">
              <h3 className="font-serif text-2xl font-semibold text-primary">Dial Strivenii Luxe</h3>
              <p className="text-xs text-on-surface-variant max-w-xs mx-auto">
                Reach out directly to schedule bespoke packages or private boutique sessions at Goregaon West, Mumbai.
              </p>
            </div>

            <div className="rose-gold-gradient-line w-full"></div>

            <div className="space-y-3">
              <a
                href="tel:+919820012345"
                className="block bg-primary text-white py-3.5 rounded-full font-sans text-xs uppercase tracking-widest font-bold hover:shadow-lg transition-all"
              >
                +91 98200 12345
              </a>
              <a
                href="https://wa.me/919820012345?text=Hi%20Strivenii,%20I'd%20like%20to%20book%20a%20bespoke%20appointment."
                target="_blank"
                rel="noopener noreferrer"
                className="block border border-primary text-primary hover:bg-primary/5 py-3.5 rounded-full font-sans text-xs uppercase tracking-widest font-bold transition-all"
              >
                Direct WhatsApp Chat
              </a>
            </div>

            <p className="text-[10px] text-on-surface-variant/60">
              Reception Desk: Mon - Sat 10 AM to 9 PM, Sun 11 AM to 7 PM
            </p>
          </div>
        </div>
      )}

      {/* Header component */}
      <Header onBookClick={handleBookingClick} onCallClick={handleCallClick} />

      <main>
        {/* Hero Section */}
        <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden scroll-smooth">
          <div className="absolute inset-0 z-0">
            <img
              src={HERO_IMAGE}
              alt="Luxury beauty salon interior with plush velvet seating in Mumbai"
              className="w-full h-full object-cover"
            />
            {/* Elegant overlay to enhance text contrast */}
            <div className="absolute inset-0 bg-black/45 md:bg-black/35 backdrop-brightness-95"></div>
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 w-full py-12">
            <div className="max-w-2xl text-left">
              <div className="flex flex-wrap items-center gap-3 md:gap-4 mb-6 md:mb-8">
                <div className="flex items-center text-yellow-500">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={15} className="fill-current text-yellow-400" />
                  ))}
                </div>
                <span className="text-white text-xs font-semibold uppercase tracking-wider font-sans">
                  4.9 Rating (1.4k+ Reviews)
                </span>
                <span className="bg-primary/20 backdrop-blur-md border border-primary/30 py-1 px-3 rounded-full flex items-center space-x-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary-fixed block"></span>
                  <span className="text-white text-[10px] font-bold uppercase tracking-widest font-sans">
                    Women-Owned
                  </span>
                </span>
              </div>

              <h1 className="font-serif text-3xl sm:text-5xl md:text-6xl text-white mb-6 md:mb-8 leading-tight font-medium">
                Strivenii: <span className="italic font-light font-serif block sm:inline mt-1 sm:mt-0">Modern Opulence</span>
              </h1>
              
              <p className="text-white/90 text-sm sm:text-base leading-relaxed mb-10 md:mb-12 max-w-lg font-sans">
                Mumbai's most exclusive sanctuary for personalized hair artistry and holistic beauty. Experience a quiet, sophisticated transformation crafted entirely by masters of the craft.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  id="hero-cta-book"
                  onClick={handleBookingClick}
                  className="bg-primary text-white hover:bg-primary/95 text-xs font-bold py-4 px-10 rounded-full uppercase tracking-widest transition-all cursor-pointer shadow-lg hover:shadow-primary/15"
                >
                  Book Appointment
                </button>
                <button
                  id="hero-cta-call"
                  onClick={handleCallClick}
                  className="glass border border-white/40 text-white hover:bg-white/10 text-xs font-bold py-4 px-10 rounded-full uppercase tracking-widest transition-all cursor-pointer flex items-center justify-center space-x-2"
                >
                  <Phone size={14} />
                  <span>Call Now</span>
                </button>
              </div>
            </div>
          </div>

          {/* Thin bottom accent bar */}
          <div className="absolute bottom-0 left-0 w-full height-[1px] rose-gold-gradient-line"></div>
        </section>

        {/* About Section - "The Strivenii Story" */}
        <section id="about" className="py-16 md:py-24 bg-surface overflow-hidden scroll-smooth">
          <div className="max-w-7xl mx-auto px-5 md:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
              
              <div className="relative group">
                <div className="aspect-[4/5] overflow-hidden rounded-2xl shadow-2xl border border-primary/5">
                  <img
                    src={ABOUT_IMAGE}
                    alt="Professional female beauty expert at Strivenii"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-103"
                  />
                </div>
                {/* Floating signature glass card detailing personalized luxury styling */}
                <div className="absolute -bottom-6 -right-4 md:-right-6 glass p-6 md:p-8 rounded-2xl hidden sm:block max-w-xs shadow-xl border border-white/60 bg-white/45">
                  <p className="font-serif text-2xl text-primary italic mb-2.5 font-semibold">Bespoke</p>
                  <p className="font-sans text-xs text-on-surface-variant leading-relaxed">
                    Every service is a unique, sensory dialogue between our clinical standards and your personal vision.
                  </p>
                </div>
              </div>

              <div className="lg:pl-8">
                <span className="font-sans text-xs uppercase tracking-[0.3em] font-bold text-primary block mb-3">
                  Our Legacy
                </span>
                <h2 className="font-serif text-3xl md:text-5xl font-semibold text-on-surface mb-8 leading-tight">
                  The Strivenii Story
                </h2>
                <div className="rose-gold-gradient-line mb-8 w-24"></div>
                
                <p className="font-sans text-sm md:text-base text-on-surface-variant mb-6 leading-relaxed">
                  Founded on the principal guideline of "Modern Opulence," Strivenii is Mumbai's premier women-owned luxury sanctuary born in the heart of the city. We believe that professional styling is not merely a service, but a curated, sensory experience of self-care.
                </p>
                
                <p className="font-sans text-sm md:text-base text-on-surface-variant mb-10 leading-relaxed">
                  Our handpicked team of master stylists, beauty doctors, and skin therapists are dedicated to implementing bespoke treatments, using only the world's most prestigious botanical products to ensure you radiate brilliance.
                </p>

                <button
                  onClick={handleBookingClick}
                  className="border-b-2 border-primary text-primary font-sans text-xs uppercase tracking-widest font-bold pb-1 hover:opacity-75 transition-opacity cursor-pointer"
                >
                  Read Our Philosophy
                </button>
              </div>

            </div>
          </div>
        </section>

        {/* Services & Cuts Component */}
        <ServicesSection onSelectService={handleSelectService} />

        {/* Why Choose Us & Statistics Component */}
        <StatsSection />

        {/* Transforms Portfolio & Photo Gallery Component */}
        <GallerySection />

        {/* Customer Testimonials Component */}
        <TestimonialsSection />

        {/* Securing Appointments Booking Calendar Component */}
        <BookingSection
          ref={bookingRef}
          selectedServiceId={selectedServiceId}
          onBookingCreated={handleBookingCreated}
        />

        {/* Goregaon Salon Location Maps & Hours Component */}
        <ContactSection />
      </main>

      {/* Footer component */}
      <Footer />

      {/* Mobile Navigation Shell - matches visual aesthetic of prompt perfectly */}
      <nav className="md:hidden fixed bottom-0 left-0 w-full bg-surface border-t border-outline-variant/20 px-4 py-2.5 flex justify-between items-center z-40 shadow-xl">
        <a
          href="#home"
          onClick={(e) => handleMobileNavClick(e, 'home')}
          className="flex flex-col items-center text-primary group"
        >
          <span className="w-5 h-5 flex items-center justify-center">
            <Heart size={18} className="fill-current text-primary" />
          </span>
          <span className="text-[9px] font-bold uppercase tracking-wider mt-1 font-sans">Home</span>
        </a>

        <a
          href="#services"
          onClick={(e) => handleMobileNavClick(e, 'services')}
          className="flex flex-col items-center text-on-surface-variant hover:text-primary group"
        >
          <span className="w-5 h-5 flex items-center justify-center">
            <Sparkles size={18} />
          </span>
          <span className="text-[9px] font-bold uppercase tracking-wider mt-1 font-sans">Menu</span>
        </a>

        <a
          href="#gallery"
          onClick={(e) => handleMobileNavClick(e, 'gallery')}
          className="flex flex-col items-center text-on-surface-variant hover:text-primary group"
        >
          <span className="w-5 h-5 flex items-center justify-center">
            <Scissors size={18} />
          </span>
          <span className="text-[9px] font-bold uppercase tracking-wider mt-1 font-sans">Styling</span>
        </a>

        <button
          onClick={handleBookingClick}
          className="flex flex-col items-center text-on-surface-variant hover:text-primary group cursor-pointer"
        >
          <span className="w-5 h-5 flex items-center justify-center text-primary">
            <UserCheck size={18} />
          </span>
          <span className="text-[9px] font-bold uppercase tracking-wider mt-1 font-sans text-primary-fixed-dim">Book Now</span>
        </button>

        <a
          href="#contact"
          onClick={(e) => handleMobileNavClick(e, 'contact')}
          className="flex flex-col items-center text-on-surface-variant hover:text-primary group"
        >
          <span className="w-5 h-5 flex items-center justify-center">
            <Phone size={16} />
          </span>
          <span className="text-[9px] font-bold uppercase tracking-wider mt-1 font-sans">Connect</span>
        </a>
      </nav>

    </div>
  );
}
